﻿namespace Task1
{
    public class Category
    {
        public string Name { get; set; }
    }
}
